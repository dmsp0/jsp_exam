package producttest;

import java.util.Objects;

// DTO 역할 : private으로 잡기, 외부에서 처리하지 못하도록
// DTO는 DB와 연동이 가능하도록 하는 것이다. (담아서 끌고 오고 보내주는 수레 역할)
public class Product {
	private String id; // 과일의 상품 번호
	private String name; // 과일명
	private int price; // 가격
	private String date; // 입고일

	// 이후부터 자동생성되도록 하는 것은 롬복(lombok). 차후에 다운받아 처리할 예정

	// 생성자
	public Product(String id, String name, int price, String date) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.date = date;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	// toString()
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", date=" + date + "]";
	}

	// equals와 hashCode 재정의
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return Objects.equals(id, other.id);
	}

}
