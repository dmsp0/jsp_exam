package producttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
// DB에 연동한다면 DAO 역할
// 예제로는 DB 연결 없이 객체를 생성할 샘플 데이터를 만들어
// Map 형태로 메모리에 저장하고 사용할 예정

import com.mysql.cj.x.protobuf.MysqlxCrud.Delete;

// Controller에게 전체 상품목록과 개별 상품 정보, 삭제 정보, 갱신 정보를 
// 제공하기 위한 서비스 클래스 
public class ProductService {
	// DB연동을 하지 않은 상태로
	// 객체를 생성하자마다 기본 자료를 만들어 놓고 싶다.
	// 기본자료는 생성자에 넣으면 됨.

	// DB로 연동한다면 PK는 id가 될 것이며 id는 기본키로 Map에서 키로 사용한다.

	Map<String, Product> products = new HashMap<>();

	public ProductService() { // 생성자, 초기화, 제품목록 만들기
		products.put("101", new Product("101", "사과", 5000, "2024-3-1"));
		products.put("102", new Product("102", "딸기", 8000, "2024-3-1"));
		products.put("103", new Product("103", "배", 7000, "2024-3-2"));
		products.put("104", new Product("104", "참외", 4500, "2024-3-3"));
		products.put("105", new Product("105", "수박", 8500, "2024-3-3"));
		products.put("106", new Product("106", "귤", 6000, "2024-3-5"));
		products.put("107", new Product("107", "체리", 8000, "2024-3-6"));
	}

	// 제품 목록 리스트 - 전체 목록 리스트로 찾기 findAll()
	// productList.jsp
	public List<Product> findAll() {
		return new ArrayList<Product>(products.values());
	}

	// 개별 상품 상제 정보 : id를 통해 들어가야한다. - find(찾는 항목에 대한 값)
	// productInfo.jsp
	public Product find(String id) {
		return products.get(id); // id에 해당되는 값 정보 확인
	}

	// 삭제 작업 - delete(삭제할 항목) : 삭제 후에는 전체 목록 페이지로 이동
	// productList.jsp
	public List<Product> delete(String id) {
		products.remove(id); // id를 키로 사용, id에 해당하는 자료 삭제
		return new ArrayList<Product>(products.values()); // 삭제된 자료 제거 후 남은 리스트 목록
	}

	// 수정 작업 - update(수정할 항목)
	// productInfo.jsp

}
