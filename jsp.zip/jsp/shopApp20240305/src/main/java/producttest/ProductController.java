package producttest;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/pcontrol") // 매핑명
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ProductService service; // DAO 역할의 클래스 생성자 호출
	// 전체 상품목록과 개별 상품 정보, 삭제 정보, 갱신 정보를 제공받음.

	public ProductController() {
		super();

		// 객체 생성, 모든 사용자 요청에 대해 동일한 객체(=인스턴스) 사용
		service = new ProductService();
	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 클라이언트 요청 구분 -> 처리 메소드 호출 -> 뷰로 이동하는 작업

		String view = ""; // 뷰 페이지를 담을 변수
		String action = request.getParameter("action");

		// action의 값이 null일 때도 있고 값이 null이 아닐 때도 있음
		if (action == null) {
			// null인 경우 자기 자신을 호출하도록, 뷰 페이지 이동
			// 뷰페이지로 이동
			// response.sendRedirect("이동할 페이지") - 가져갈 데이터 없을 때
			// getServletContext().getRequestDispatcher("이동할 페이지").forward(request,
			// response); - 가져갈 데이터 있을 때
			/*
			 * forward 액션 : 클라이언트 요청을 다른 페이지로 전환하는 액션 클라이언트가 새롭게 접속하는 것이 아니라 서버에서 내부적으로 새로운
			 * 페이지로 이동을 하고 그 페이지의 내용을 클라이언트에게 응답으로 전달 최초 request를 유지하거나 request의
			 * setAttribute()로 속성값을 저장한 경우 이를 유지하면서 페이지를 이동해야 하므로 forward가 적합 redirection :
			 * 서버가 클라이언트에게 새로운 페이지로 다시 접속하도록 응답을 보내고 응답 받은 클라이언트가 다시 새로운 페이지로 접속하는 방식 단순한
			 * 페이지 이동이 필요한 경우라면 리디렉션이 적합
			 */

			getServletContext().getRequestDispatcher("/pcontrol?action=list").forward(request, response);

		} else {
			switch (action) {
			case "list":
				view = list(request, response);
				break;
			case "info":
				view = info(request, response);
				break;
			case "delete":
				view = delete(request, response);
				break;
			case "send":
				view = "sendTest.jsp";
				break;
			}

			// 뷰 페이지로 이동
			getServletContext().getRequestDispatcher("/" + view).forward(request, response);
			// /는 경로
		}

	} // end of service

	public String list(HttpServletRequest request, HttpServletResponse response) {
		request.setAttribute("products", service.findAll());
		return "productList.jsp";
	}

	public String info(HttpServletRequest request, HttpServletResponse response) {
		request.setAttribute("pro", service.find(request.getParameter("id")));
		return "productInfo.jsp";
	}

	public String delete(HttpServletRequest request, HttpServletResponse response) {
		request.setAttribute("products", service.delete(request.getParameter("id")));
		return "productList.jsp";
	}

}
