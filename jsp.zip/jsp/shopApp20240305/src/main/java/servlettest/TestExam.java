/*
 * package servlettest;
 * 
 * public class TestExam {
 * 
 * public static void main(String[] args) { LombokTest lom = new LombokTest();
 * 
 * 
 * }
 * 
 * }
 */