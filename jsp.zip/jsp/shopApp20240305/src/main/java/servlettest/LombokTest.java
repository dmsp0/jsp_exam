/*
 * package servlettest;
 * 
 * import lombok.AllArgsConstructor; import lombok.Data; import
 * lombok.EqualsAndHashCode; import lombok.Getter; import
 * lombok.NoArgsConstructor; import lombok.Setter; import lombok.ToString;
 * 
 * //@Getter // getter 메소드 추가 //@Setter // setter 메소드 추가 //@ToString // toString
 * 메소드 추가 //@NoArgsConstructor // 기본 생성자 //@AllArgsConstructor // 모든 멤버 변수를
 * 초기화하는 생성자 추가 //@EqualsAndHashCode // equals(), hashCode() 메소드 추가
 * 
 * @Data //위에 선언한 @NoArgsConstructor 외에 모든 것 추가됨.
 * 
 * public class LombokTest { private String name; private int age;
 * 
 * }
 */