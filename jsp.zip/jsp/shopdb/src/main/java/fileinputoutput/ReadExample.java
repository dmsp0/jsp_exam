package fileinputoutput;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class ReadExample {

	public static void main(String[] args) throws IOException {
		String  r = "c:/temp/test10.txt";
		Reader reader = new FileReader(r);
		
		while(true) {
			int data = reader.read(); // 한문자씩 읽기
			if(data==-1) {break;}
			System.out.println((char)data); // 문자로 명시적(강제) 형변환
			
		}

		reader.close(); // 입력 스트림 닫기.
	}

}
