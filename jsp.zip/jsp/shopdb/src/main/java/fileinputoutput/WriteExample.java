package fileinputoutput;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class WriteExample {

	public static void main(String[] args) {
		try {
			OutputStream os = new FileOutputStream("c:\\temp\\test1.db");

			byte a = 10;
			byte b = 20;
			byte c = 30;

			byte[] arry = { 40, 50, 60, 70, 80, 90 };

			try {
				os.write(a); // 1byte 씩 출력
				os.write(b);
				os.write(c);

				os.write(arry);
				// os.write(arry, 1, 3); // 인덱스 1번부터 3개 작성

				os.flush(); // 버퍼 내용 모두 출력하기 (버퍼 비우기)
				os.close(); // 출력 스트림 닫기

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
