package fileinputoutput;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class InputOutputExam {

	public static void main(String[] args) {
		String input = "c:\\temp\\a.txt";
		String output = "c:\\temp\\b.txt";

		// 파일 입력 스트림 : 파일읽어오기 -> 처리 -> 종료(close)
		// 파일 출력 스트림 : 파일 열기 -> 처리 -> 종료(close)
		// try - with - resource : close()를 자동 처리
		
		try(FileInputStream fis = new FileInputStream(input);
			FileOutputStream fos = new FileOutputStream(output)){
			
			// file을 읽어서 바로file로 내보내기
			int c; // fis.read(); -1byte씩 읽어오기
			       // 더이상 읽을 내용이 없으면 -1 을 리턴
			while((c=fis.read()) != -1) {
				fos.write(c); // 1byte 씩 쓰기
				System.out.printf("%c(%d)", (char)c,c);
			}
			
			
		} catch(IOException e) {
			System.out.println("예외 발생");
			e.printStackTrace();
		}
		
	}

}
