package fileinputoutput;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class InputStreamExam {
	public static void main(String[] args) {

		try {
			InputStream is = new FileInputStream("c:\\temp\\test1.db");
			while (true) {
				try {
					int data = is.read();
					if (data == -1) { // 더 이상 읽어올 자료가 없으면 -1을 리턴
						break;
					}
					System.out.println(data);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // 1byte 씩 읽기
			}
			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 1byte 씩 읽기

	}

}
