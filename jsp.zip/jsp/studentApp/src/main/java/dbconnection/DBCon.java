package dbconnection;

public abstract class DBCon {                            
	                                                             //DB명만 수정해서 사용하면 됨
	public final static String URL = "jdbc:mysql://localhost:3306/studentdb?serverTimezone=UTC"; 
	public final static String USER = "root"; // 사용자명 수정해서 사용해야 함
	public final static String PASSWORD ="my1234";
}
