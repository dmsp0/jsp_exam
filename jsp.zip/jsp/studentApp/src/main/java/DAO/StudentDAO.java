package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DTO.Student;
import dbconnection.MyDBConnection;

// DB 자료를 전달하거나 자료를 가져오기 위함 
public class StudentDAO {
//	private Connection con = null;
//	private PreparedStatement pstmt = null;
//	private ResultSet rs = null;
	
	Connection con = null; // sql 연결
	PreparedStatement pstmt = null; // sql 전달
	ResultSet rs = null; // sql 실행, 결과 받기
	
	// 학생 등록 - insert를 위한 것, 
	// 폼으로부터 입력을 받아 컨트롤러가 가져다가 
	// DTO라는 수레에 담아 가져오고 DAO에 보내서 DB에 삽입하는 것이 목적
	public void insert(Student student) { // DTO 수레를 매개값으로 받는 것
		String sql = "insert into student(id, name, email) values(?,?,?)";
		
		con = MyDBConnection.getConnection();
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, student.getId());
			pstmt.setString(2, student.getName());
			pstmt.setString(3, student.getEmail());
			
			pstmt.executeUpdate(); // insert, delete, update
			
		} catch (SQLException e) {
			System.out.println("예외 발생"); // 프로그램 완료 후 반드시 주석 또는 제거
		} finally {
			MyDBConnection.close(rs, pstmt, con);
		}	
	} // end of insert()
	
	
	// 학생 리스트 - sql의 자료를 가져와 전체를 출력하기 위한 목적
	// DB에서 전체 리스트를 읽어와서 DTO 수레에 담아 컨트롤러에게 전달
	public List<Student> getAll() { //findAll()
		List<Student> students = new ArrayList<>();
		String sql = "select * from student";
		
		con = MyDBConnection.getConnection();
		
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery(); // select
			
			//ResultSet에 있는 내용 가져오기
			while(rs.next()) {
				//Student라는 객체를 생성해서 자료를 담기
				Student std = new Student(); // 각 자료에 대한 객체 
				
				std.setId(rs.getInt(1)); // id
				std.setName(rs.getString(2)); // name
				std.setEmail(rs.getString(3)); // email
				
				// 객체를 ArrayList 배열에 추가
				students.add(std);
			}
		} catch (SQLException e) {
			System.out.println("예외 발생"); // 프로그램 완료 후 반드시 주석 또는 제거
		} finally {
			MyDBConnection.close(rs, pstmt, con);
		}
		
		return students; // 전체 자료를 담고 있는 배열변수를 반환한다.
		
	} // end of getAll()
	

} // end of class
