package com.choong.web.command;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpFilter;

//filter : 여러 서블릿 클래스에서 반복되는 코드를 일괄적으로 처리할 때 사용
//			특정 서블릿이 실행되기 전에 먼저 동작하여 서블릿에 대한 사전 처리 작업 수행
//     web.xml 
//        필터는 서블릿과 달리 서블릿 컨테이너가 구동되는 시점에 생성됨
//        이렇게 컨테니어가 구동(생성)되는 시점에 객체가 생성되는 것을 pre-loading이라고 함
//   서블릿 컨테이가 구동될 때 필터가 먼저 생성되고, 브라우저(클라이언트)가 특정 서블릿으ㅡㄹ
//   요청(request) 하는 순간 서블릿과 관련된 필터가 먼저 실행
//    필터는 서블릿이 수행되기 전에 처리해야할 작업을 수행한 후 요청된 서블릿을 호출

          // urlPatterns{ }안에 특정 여러 서블릿 매핑 가능
@WebFilter(urlPatterns = {"*.do"}, 
		initParams = @WebInitParam(name="boardEncoding", value="UTF-8"))

public class CharacterEncodingFilter extends HttpFilter implements Filter {
	private static final long serialVersionUID = 1L;
	private String encoding;
	
    
    public CharacterEncodingFilter() {
        super();
    }

    public void init(FilterConfig fConfig) throws ServletException {
    	encoding = fConfig.getInitParameter("boardEncoding");
    }

    //doFilter() 메소드가 실질적으로 필터가 제공하는 사전처리와 사후 처리 로직을 작성하는 부분
    // 필터에서 사전 처리를 수행하고 나서 브라우저(클라이언트)가 요청한 서블릿으로 호출을 
    // 전달하기 위해서는 doFilter()메소드에서 매개변수로 받은 FilterChain 객체의 doFilter()
    //를 호출해야 함, 그렇지 않으면 사용자가 호출한 서블릿은 절대 실행되지 않음
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		// pass the request along the filter chain(요청을 필터 체인에 넘기기)
		// 서블릿이 수행되기 전에 인코딩을 처리한다.
		request.setCharacterEncoding(encoding);
		chain.doFilter(request, response);
	}

	public void destroy() {
		
	}
	

}
