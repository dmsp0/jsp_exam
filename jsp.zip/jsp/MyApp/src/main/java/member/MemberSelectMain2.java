package member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbconnection.MyDBConnection;

public class MemberSelectMain2 {
	// DB에서 값 가져오기
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// 쿼리문 띄어쓰기 주의하기
		String sql = "select memberId, memberName " + "from member ";

		// con = getConnection();
		con = MyDBConnection.getConnection(); // sql 접속
		try {
			pstmt = con.prepareStatement(sql); // sqp 전달

			// sql 실행시키고 결과 가져오기
			rs = pstmt.executeQuery(); // executeUpdate() : insert, update, delete 실행

			// 가져온 결과를 확인하기
			while (rs.next()) {
				// System.out.println(rs.getInt(1) + " : " + rs.getString(2));
				Member member = new Member();
				member.setMemberId(rs.getInt(1)); // member.setMemberId(rs.getInt("memberId"));
				member.setMemberName(rs.getString(2));

				System.out.println(member);
			}
			System.out.println("자료 없음");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			MyDBConnection.close(rs, pstmt, con);
		}

	}

//	private static Connection getConnection() {
//		return MyDBConnection.getConnection();
//	}
}
