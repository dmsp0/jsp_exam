package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static dbconnection.DBCon.*;

public class MyDBConnection {
	//구현할 Connection 객체를 넘겨주어야 함
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//con = DriverManager.getConnection(DBCon.URL, DBCon.USER, DBCon.PASSWORD);
			System.out.println("접속 성공");
		} catch (ClassNotFoundException e) {
			e.printStackTrace(); // 나중에 제거 또는 주석 처리
		} catch (SQLException e) {
			System.out.println("접속 실패");
			e.printStackTrace();
		}
		return con;
	}
	
	// 일처리 모두 끝난 경우 자원 닫기 메소드//전달된 결과 받아오는 , SQL문을 전달하는, DB를 연결하는
	public static  void close(ResultSet rs, PreparedStatement pstmt, Connection con) {
		// 마지막 작업 부터 순차적으로 닫아주어야 한다.
		if(rs!=null) {//전달된 결과 받아오는
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(pstmt!=null) { //SQL문을 전달하는
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(con!=null) { //DB를 연결하는
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	
	}
	
}
