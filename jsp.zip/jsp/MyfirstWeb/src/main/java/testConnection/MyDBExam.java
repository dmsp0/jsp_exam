package testConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbconnection.MyDBConnection;

public class MyDBExam {

	public static void main(String[] args) {
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		// java에서는 sql구문을 문자열로 처리
		String sql = "insert into member(memberId, memberName) values(?,?)";
		
		try {
		con = MyDBConnection.getConnection(); // db연결
		
		pstmt = con.prepareStatement(sql); // 전달
		pstmt.setInt(1, 686); // pk키
		pstmt.setString(2, "홍길동");

		// sql문 실행
		// executeUpdate() : insert, update, delete
		// executeQuery() : select
		
		// 결과 안보고 실행시킬 때
		// pstmt.executeUpdate();
		
		// 결과 확인하고 싶을 때
		int result = pstmt.executeUpdate(); // sql문을 실행시켜줘
		System.out.println("실행결과:"+result);
		
		}catch(SQLException e) {
			System.out.println("예외발생");
			//e.printStackTrace(); // 프로그램 완성한 후 제거 또는 주석
		}finally {
			MyDBConnection.close(con, pstmt, rs);
		}
		
	}
}
