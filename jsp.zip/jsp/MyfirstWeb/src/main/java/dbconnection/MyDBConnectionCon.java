package dbconnection;

public abstract class MyDBConnectionCon { // 추상클래스 또는 인터페이스 : 객체 생성 불가
	// 접근제한자 final static
						  //오라클 : "jdbc:oracle:thin:@localhost:1521:데이터베이스명" 
	public final static String URL = "jdbc:mysql://localhost:3306/jdbctestdb?serverTimezone=UTC";
	public final static String USER = "root";
	public final static String PASSWORD ="my1234";
	
	// private MyDBConnectionCon() {} - 생성자, 객체 생성 제한할 때
}
