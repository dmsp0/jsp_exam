package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static dbconnection.MyDBConnectionCon.*;

public class MyDBConnection { // db접속과 접속 끊기
	public static Connection getConnection() {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			// 오라클 : Class.forName("oracle.jdbc.OracleDriver");
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);

			System.out.println("DB 접속 성공");

		} catch (ClassNotFoundException e) {
			System.out.println("찾는 파일 없음");
		} catch (SQLException e) {
			System.out.println("접속 실패");
		}

		return con;
	}
	
	public static void close(Connection con, PreparedStatement pstmt, ResultSet rs) {
		if(rs != null) {
			try {
				rs.close();
				System.out.println("rs 닫기 성공");
			} catch (SQLException e) {
				System.out.println("rs 닫기 실패");
			}
		}
		if(pstmt != null) {
			try {
				pstmt.close();
				System.out.println("pstmt 닫기 성공");
			} catch (SQLException e) {
				System.out.println("pstmt 닫기 실패");
			}
		}
		if(con != null) {
			try {
				con.close();
				System.out.println("con 닫기 성공");
			} catch (SQLException e) {
				System.out.println("con 닫기 실패");
			}
		}
	}

}

